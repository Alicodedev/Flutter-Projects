import 'package:flutter/material.dart';

void main(){
  runApp(
    MaterialApp(
      home: HomePage(),
    ),
  );
}

class HomePage extends StatelessWidget{
  @override
  Widget build(BuildContext context) {
    var titles = [ // prayer names/titles
      'Fajr',
      'Sunrise',
      'Duhr',
      'Asr',
      'Maghrib',
      'Isha',
      'Qiyam'
    ];

    var times = [ // prayer times
      '6:21 AM',
      '7:43 AM',
      '12:31 PM',
      '2:58 PM',
      '5:19 PM',
      '6:42 PM',
      '1:59 AM',
    ];

    Widget getPrayerTitle(int index) {
      if (index == 1) {
        return Image.asset(
          'images/sunrise.png',
          width: 30,
          height: 30,
          fit: BoxFit.cover,
        );
      } else if (index == 6) {
        return Image.asset(
          'images/qiyam.png',
          width: 30,
          height: 30,
        );
      } else {
        return Container(
          width: 30,
          height: 30,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            border: Border.all(
                color: Colors.deepPurpleAccent,
                width: 5.0
            ),
          ),
        );
      }
    }

    Widget getPrayerAlarm(int index) {
      if (index == 0 || index == 1 || index == 6) {
        return Image.asset( //set specific indexes as slient
          'images/slient.jpg',
          width: 30,
          height: 30,
        );
      } else { // set rest of the indexes as alarm on
        return Image.asset(
          'images/speaker.png',
          width: 30,
          height: 30,
        );
      }
    }

    return SafeArea(
      child: Scaffold(
        backgroundColor: Colors.white,
        appBar: AppBar(
          backgroundColor: Colors.white,
          surfaceTintColor: Colors.transparent,
          shadowColor: Colors.grey[300],
          elevation: 4.0,
          title: Text(
            'Prayer Times',
            style: TextStyle(color: Colors.black),
          ),

        ),
        body: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Padding(
              padding: EdgeInsets.all(16.0),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween, // items spread evenly
                children: [
                  Text(
                    'Today',
                    style: TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  Row(
                    children: [
                      Image.asset(
                        'images/share.png', // share icon
                        width: 24,
                        height: 24,
                      ),
                      SizedBox(width: 45), // Spacing between icons
                      Image.asset(
                        'images/calender.png', // Calender icon
                        width: 24,
                        height: 24,
                      ),
                    ],
                  ),
                ],
              ),
            ),
            Expanded( // Expanded widget to fill the available space
              child: ListView.builder(
                itemCount: titles.length,
                itemBuilder: (context, index) {
                  return ListTile(
                    leading: getPrayerTitle(index),// getting prayer title image by index
                    title: Text(
                      titles[index],
                      style: TextStyle(
                        fontSize: 20,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    trailing: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Text(
                          times[index],
                          style: TextStyle(
                            color: Colors.black,
                            fontSize: 20,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        SizedBox(width: 8),
                        getPrayerAlarm(index),// getting prayer alarm image by index
                      ],
                    ),
                  );
                },),

            ),
          ],
        ),
      ),
    );
  }
}