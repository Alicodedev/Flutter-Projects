import 'package:flutter/material.dart';
void main() {
  runApp(
    MaterialApp(
      home: Scaffold(
        backgroundColor: Colors.deepOrange[50],
        appBar: AppBar(
          title: Text("Canada Paint App"),
          backgroundColor: Colors.red[50],
        ),
        body: Center(
          child: Image.asset('images/canada-flag.png', width: 500),

        ),

      ),
    ),
  );
}
