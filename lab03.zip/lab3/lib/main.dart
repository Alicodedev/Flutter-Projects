import 'package:flutter/material.dart';
import 'dart:math';

void main() {
  runApp(
    MaterialApp(
      home: HomePage(),
    ),
  );
}

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {

  final Map<int, String> _imageMap = {
    1: 'Paper',
    2: 'Rock',
    3: 'Scissors',
    4: 'Lizard',
    5: 'Spock',
  };

  var random = Random();
  int _firstImage = Random().nextInt(5) + 1;
  int _secondImage = Random().nextInt(5) + 1;
  String _result = '';
  Color _firstImageColor = Colors.transparent;
  Color _secondImageColor = Colors.transparent;
  int _firstImageScore = 0;
  int _secondImageScore = 0;

  void _updateImages() {
    setState(() {
      _firstImage = Random().nextInt(5) + 1;
      _secondImage = Random().nextInt(5) + 1;
      _determineWinner();
    });
  }

  void _determineWinner() { // Determine the winner based on the images
    if (_firstImage == _secondImage) {
      _result = 'It\'s a tie!';
      _firstImageColor = Colors.transparent;
      _secondImageColor = Colors.transparent;
    } else if ((_firstImage == 3 && _secondImage == 1) || // all possible conditinos for both
        (_firstImage == 1 && _secondImage == 2) ||
        (_firstImage == 2 && _secondImage == 4) ||
        (_firstImage == 4 && _secondImage == 5) ||
        (_firstImage == 5 && _secondImage == 3) ||
        (_firstImage == 3 && _secondImage == 4) ||
        (_firstImage == 4 && _secondImage == 1) ||
        (_firstImage == 1 && _secondImage == 5) ||
        (_firstImage == 5 && _secondImage == 2) ||
        (_firstImage == 2 && _secondImage == 3)) {

      _result ='${_imageMap[_firstImage]} wins!';
      _firstImageColor = Colors.lightGreen;
      _secondImageColor = Colors.transparent;
      _firstImageScore++; // score increment
    } else {
      _result = '${_imageMap[_secondImage]} wins!';
      _firstImageColor = Colors.transparent;
      _secondImageColor = Colors.lightGreen;
      _secondImageScore++;
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Rock Paper Scissors'),
        backgroundColor: Colors.teal[50],
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Row(
              children: [
                Expanded(
                  child: Container(
                    color: _firstImageColor,
                    child: TextButton(
                      child: Image.asset('images/image$_firstImage.png'),
                      onPressed: () {
                        _updateImages();
                      },
                    ),
                  ),
                ),
                Expanded(
                  child: Container(
                    color: _secondImageColor,

                    child: TextButton(
                      child: Image.asset('images/image$_secondImage.png'),
                      onPressed: () { // event triggered when image is pressed
                        _updateImages(); // updates 
                      },
                    ),
                  ),
                ),
              ],
            ),
            SizedBox(height: 20),
            Text(
              _result,
              style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
            ),
            SizedBox(height: 20),
            Row( // score status for both first and second image
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                Text(
                  'Score: $_firstImageScore',
                ),
                Text(
                  'Score: $_secondImageScore',
                ),

              ],
            ),
          ],
        ),
      ),
    );
  }
}